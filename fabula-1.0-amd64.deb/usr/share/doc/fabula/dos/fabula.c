/*
---------------------------------------------------------------------
FABULA, the human robot
by M. Andreoli, (C) 1994

This program was originally in PASCAL. It had been
translate in C language using P2C pascal-to-c translator.
Recently, I removed any reference to P2C libraries (2002)
---------------------------------------------------------------------
*/

#include "fabula.h"

#define fabula_key "fabula.key"
#define fabula_db "fabula.db"

/* Procedure e funzioni usate */

Static Void Reply PP((Char *frase, int FoundKey));

Static Void Interpret PP((Char *frase));

Static boolean ProcessCommand PP((Char *frase));

Static boolean ProcessOp PP((Char *frase, int k));

Static boolean Grep PP((Char *frase));

Static Void Load PV();

Static Void Save PV();

Static Void Status PV();

Static Void Impara PV();

Static Void Dimentica PP((Char *frase));

Static Void Store PP((Char *frase));

Static Void Print PP((Char *s));

Static Char *Upper PP((Char *Result, Char *s));


#include "lib.h"

/* Elimina roba non stampabile, per usi con TELNET */

void CheckForEscape( char *s)
{
char new[256];

int i=0,j=0;

	while ( s[i] != '\0' )
	{
 	if ( (s[i] >=32 ) && (s[i] <= 122) ) 
		{ new[j]=s[i]; j++;}
	i++;
	}
	new[j]='\0';
	strcpy(s,new);
}

/* Generiche */


#define sep             '|'

#define tab             "     "
#define lst_            "printer: "


#define MaxKey          100


typedef Char StringType[91];


typedef StringType StringVector[MaxKey];


typedef Char CharVector[MaxKey];


#define MaxDB           300



/* Variabili di stato interno */

Static boolean trace_on, sound_on, printer_on, slow_on;
Static int NumBattute;
Static int interactive;

/* Struttura generale della conoscenza di Fabula */
Static int NuoveChiavi, NuoveFrasi, nkey;
Static StringVector key;
Static CharVector op;
Static StringVector model;
Static int ndb;

/* Static StringType db[MaxDB]; */

char db[MaxDB][100];


Static Char LastInput[256];
Static Char UserInput[256];
Static int i;
Static Char a[256], s[256];


/* Funzioni definite per compatibilita'
---------------------------------------------------*/
Static Void do_delay(t)
int *t;
{
}

#ifdef _LINUX_
void delay( unsigned ms ) {
	usleep( ms * 1000 );
}
#endif

Static Void sound(s)
int *s;
{
putchar('\07');
}


Static Void nosound()
{
}
 /*
 numero a caso tra 0..max-1
 */

int _randint(int max)
{
return (int) rand()%max; 
}


Static Void switch_(flag)
boolean *flag;
{
  Char STR1[256];
  int old=*flag;

  *flag =  !old; 

  if ( *flag) {
    Print("Stato: attivo");
  } else
    Print("Stato: non attivo");

}


/* Metti in maiuscolo */

Static Char *Upper(Result, s_)
Char *Result;
Char *s_;
{
  Char s[256];
  int i, l;

  strcpy(s, s_);
  l = strlen(s);

  for (i = 0; i < l; i++)
    s[i] = toupper(s[i]);
  return strcpy(Result, s);
}


/* E' interrogativa ( Question Mark) */
Static boolean IsQ(s)
Char *s;
{
  Char STR1[256];

  if ( s[ strlen(s)-1 ] == '?' )
    return true;
  else
    return false;
}

 /*
 elimina il \n terminale , se c'e'
 */

void chop(char *s) {
if ( s[strlen(s)-1] == '\n' ) s[strlen(s)-1]='\0';
if ( s[strlen(s)-1] == '\r' ) s[strlen(s)-1]='\0';
}


/* Cancella, evenutalmente il '?' */
Static Char *DelQM(Result, s)
Char *Result;
Char *s;
{
  if (IsQ(s)) {
    sprintf(Result, "%.*s", (int)(strlen(s) - 1L), s);
    return Result;
  } else
    return strcpy(Result, s);
}



Static Void ReadInput(prompt, what)
Char *prompt;
Char *what;
{
  Char *TEMP;

  fputs(prompt, stdout);
  fgets(what, 91, stdin);
  TEMP = strchr(what, '\n');
  if (TEMP != NULL)
    *TEMP = 0;
}


/* Cerca la key e sceglie a caso un'occorrenza */

Static int FindKey(user)
Char *user;
{
  int Result, i, ran, start, next, lun;
  Char s[256];
  int found[MaxKey];
  int nfound;
  Char STR1[256];
  int FORLIM;
  Char STR2[256];

  Upper(s, user);   /* Metti in maiuscolo */

  /* Cerca tutte le occorrenze */
  lun = strlen(user);
  nfound = 0;
  FORLIM = nkey;
  for (i = 1; i <= FORLIM; i++) {
/*
    start = strpos2(s, DelQM(STR1, Upper(STR2, key[i - 1])), 1);
    next = start + strlen(DelQM(STR1, key[i - 1]));

    if (IsQ(s) == IsQ(key[i - 1]) && start != 0 &&
	(s[next - 1] == ' ' || next > lun)) {
      nfound++;
      found[nfound - 1] = i;
*/
    DelQM(STR1, Upper(STR2, key[i - 1]), 1);
    start = strpos2(s, STR1, 1);
	
    if (IsQ(s) == IsQ(key[i - 1]) && start != 0 ) {
      nfound++;
      found[nfound - 1] = i;

      if (trace_on)
	printf("-> Trovato: %c%s%c%s%c (N=%2d)\r\n",
	       sep, key[i - 1], sep, model[i - 1], sep, i);

    }
  }

  /* Ne prende una a caso */

  if (nfound == 0)
    return 0;
  ran = found[_randint(nfound)];
  Result = ran;
  if (trace_on)
    printf("-> Chiave scelta = %3ld\r\n", ran);
  return Result;
}


/* Estrae ante e susse */

Static boolean Extract(s, w_, ante, susse)
Char *s;
Char *w_;
Char *ante, *susse;
{
  Char w[256];
  int p, l, final;
  Char STR1[256];


  strcpy(w, w_);
  strcpy(w, Upper(STR1, w));
  p = strpos2(Upper(STR1, s), w, 1);

  *ante = '\0';
  *susse = '\0';



  if (p == 0)
    return false;

  if (p >= 3)
    sprintf(ante, "%.*s", (int)(p - 1), s);
  else
    *ante = '\0';

  l = strlen(s);
  final = p + strlen(w);

  if (final + 1 <= l)
    strsub(susse, s, (int)(final + 1), (int)l);
  else
    *susse = '\0';

  strcpy(susse, DelQM(STR1, susse));
  return true;
}


/* Sostituisci in frase, cosa -> con, ovunque */

Static Char *Substitute(Result, frase_, cosa, con)
Char *Result;
Char *frase_, *cosa, *con;
{
  Char frase[256];
  int p;

  strcpy(frase, frase_);
  do {
    p = strpos2(frase, cosa, 1);
    if (p != 0) {
      strinsert(con, (Anyptr)frase, (int)(p + strlen(cosa)));
      strdelete((Anyptr)frase, (int)p, strlen(cosa));
    }
  } while (p != 0);

  return strcpy(Result, frase);
}


/* Stampa rallentata */

Static Void Print(s_)
Char *s_;
{
int i;
int sleep_1=10*1;
int sleep_2=10*5;
char b[1000];
Upper(b,s_);
if ( ! slow_on ) { puts(b); return;}
 /*
 stampa rallentata
 */
for(i=0; i<strlen(b); i++) {
	putchar(b[i]); 
	if (sound_on ) putchar('\a');	
	delay(sleep_1);
	if ( (_randint(10) % (_randint(4)+2) ) == 0 ) delay(sleep_2);
	}
	delay(sleep_2);
	putchar('\n');
}


/* Saluti iniziali */

Static Void Init()
{
  /* Inizializzazioni variabili di stato */

  trace_on = false;
  sound_on = false;
  printer_on = false;
  slow_on = true;

  NumBattute = 0;

  NuoveChiavi = 0;
  NuoveFrasi = 0;
  ndb = 0;
  nkey = 0;


  Load();
if ( interactive )
{
  Print("Ciao!");
  Print("Io mi chiamo  F A B U L A.");
  Print("Sei hai problemi, batti HELP. Per uscire, batti CIAO.");
  Print("Comincia pure, prego!");
  Print("-----------------------------");
  Print("");
}

}


Static Void CloseDialog()
{
  Char prompt[256], s[256], s1[256], s2[256];
  Char STR2[256];
  int TEMP;


  putchar('\r');
  putchar('\n');
  Print("Salvo le informazioni sul disco, un attimo");
  Save();

  printf("La nostra breve chiacchierata e' consistita di %d battute,\r\n\
nel corso delle quali ho imparato %d nuove chiavi \
e %d nuove informazioni.\r\n",\
NumBattute,NuoveChiavi,NuoveFrasi);

  Print("E' stato un vero piacere. Alla prossima volta. Ciao! ");
}


Static Void ListKey()
{
}


/* MODULO PRINCIPALE PER L' INTERPRETAZIONE */

Static Void Interpret(frase_)
Char *frase_;
{
  Char frase[256];
  int n, r;
  Char STR2[256];
  Char STR3[124];

  strcpy(frase, frase_);
  if (printer_on)
    printf("%s%s\r\n", lst_, frase);

  if (ProcessCommand(frase))
    return;

  if ( frase[0] == '\0') {
    Print("Hai qualche problema?");
    return;
  }

 /* cerca la chiave */

  n = FindKey(frase);

  /* no ha trovato nessuna utile chiave */

  if (n == 0) {
    if (frase[strlen(frase) - 1] == '.') {
      strdelete((Anyptr)frase, strlen(frase), 1);
      Print("Questa me la segno. Comunque ...");
      Store(frase);
    }


    if (IsQ(frase) && Grep(DelQM(STR2, frase)))
      return;
    else {
      Print("Non sono sicuro di capirti pienamente");
      r = _randint(ndb);

      if (r > 0 && r % 3 == 0) {
	sprintf(STR3, "Ma, prima qualcuno ha affermato: '%s'.", db[r]);
	Print(STR3);
	Print("Se vuoi, riparliamone.");
      }
      return;
    }

  }

  if (!ProcessOp(frase, n))
    Reply(frase, n);

}


Static boolean ProcessOp(frase, k)
Char *frase;
int k;
{
  boolean Result;
  Char ante[256], susse[256];
  boolean found;
  Char STR1[256];


  Result = false;

  switch (op[k - 1]) {

  case ':':
    /* blank case */
    break;

  case '>':
    Store(frase);
    break;

  case '=':
    found = Extract(frase, DelQM(STR1, key[k - 1]), ante, susse);
    Result = Grep(susse);
    break;
  }

  return Result;
}



Static boolean Grep(frase)
Char *frase;
{
  boolean Result;
  int i;
  Char STR1[256], STR2[256], STR3[256];
  int FORLIM, TEMP;
  Char STR5[96];

  if (trace_on)
    printf("-> Cerco nel DB ..%s\r\n", frase);

  Result = false;

  FORLIM = ndb;
  for (i = 0; i < FORLIM; i++) {
    if (strpos2(Upper(STR3, db[i]), Upper(STR2, frase), 1) != 0 ||
	!strcmp(frase, "")) {
      TEMP = 1000;
      sound(&TEMP);
      TEMP = 10;
      do_delay(&TEMP);
      nosound();
      TEMP = 100;
      do_delay(&TEMP);
      printf("%s%s\r\n", tab, db[i]);
      Result = true;
      if (printer_on) {
	sprintf(STR5, "%s%s", tab, db[i]);
	printf("%s%s\r\n", lst_, Upper(STR1, STR5));
      }
    }


  }
  if (trace_on && Result)
    printf("-> DB: successo.\r\n");

  return Result;
}


Static Void Store(frase)
Char *frase;
{
  int r;

  if (ndb + 1 > MaxDB)
    r = _randint(ndb);
  else {
    ndb++;
    r = ndb;
  }

  NuoveFrasi++;
  strcpy(db[r - 1], frase);

  if (trace_on)
    printf("Memorizzo: [%s]\r\n", frase);

}


#define ncmd           10 


Static boolean ProcessCommand(frase)
Char *frase;
{
  boolean Result;
  int i, j;
  Char ante[256], susse[256];
  boolean found;
  Char c[256];

  static Char cmd[ncmd][2][256] = {
    { "help", "Elenco comandi" },
    { "lista", "Lista chiavi" },
    { "impara", "Impara nuove chiavi" },
    { "dimentica", "Dimentica Conoscenza" },
    { "trace", "Attiva/disattiva  trace" },
    { "sound", "Attiva/disattiva sound" },
    { "printer", "Attiva/disattiva printer" },
    { "slow", "Attiva/disattiva output lento" },
    { "dos", "Sessione DOS" },
    { "ciao", "Fine dialogo" }
  };

  int FORLIM;


  /* Cerca eventualmente il comando speciale */
  i = 0;
  do {
    i++;
    found = Extract(frase, cmd[i - 1][0], ante, susse);
  } while (!(found || i == ncmd));

  if (!found || *ante != '\0')
    return false;

  strcpy(c, cmd[i - 1][0]);
  Result = true;

  /* Comandi di tipo generico */

  if (!strcmp(c, "help")) {
    putchar('\r');
    putchar('\n');
    Print("Ecco un Breve elenco dei comandi di primo livello:");
    printf("------------------------------------------------\r\n\r\n");
    for (i = 0; i < ncmd; i++)
      printf("%12s  %s\r\n", cmd[i][0], cmd[i][1]);

    putchar('\r');
    putchar('\n');
    Print("Note varie:");
    printf("----------\r\n\r\n");
    printf("frase. (memorizza [frase] nel DB)\r\n");
    printf("frase? (cerca [frase] nel DB)\r\n\r\n");
    printf("dimentica * (dimentica tutto il DB)\r\n");

  }


  if (!strcmp(c, "lista")) {

    putchar('\r');
    putchar('\n');
    Print("Chiavi conosciute (col tipo)");
    printf("--------------------------\r\n");
    FORLIM = nkey;
    for (j = 1; j <= FORLIM; j++) {
      printf("%12s(%c)", key[j - 1], op[j - 1]);
      if (j % 5 == 0 || j == nkey)
	{putchar('\r'); putchar('\n');}
/* p2c: fabula.p, line 497:
 * Note: Using % for possibly-negative arguments [317] */
    }

    Status();
  }

  if (!strcmp(c, "impara"))
    Impara();


  if (!strcmp(c, "dimentica"))
    Dimentica(susse);
  if (!strcmp(c, "dos"))
/*
    system("sh");
*/
    printf("Opzione disabilitata. Mi spiace!\n");

  if (!strcmp(c, "slow"))
    switch_(&slow_on);

  if (!strcmp(c, "sound"))
    switch_(&sound_on);
  if (!strcmp(c, "trace"))
    switch_(&trace_on);

  if (!strcmp(c, "printer")) {
    switch_(&printer_on);
    printf("%sINIZIO DIALOGO\n", lst_);
    puts(lst_);
  }

  if (!strcmp(c, "ciao"))
    CloseDialog();


  return Result;
}

#undef ncmd


/* Risposta del computer */

Static Void Reply(frase, FoundKey)
Char *frase;
int FoundKey;
{
  Char risp[256], ante[256], susse[256];
  boolean found;
  Char STR2[256];

  found = Extract(frase, DelQM(STR2, key[FoundKey - 1]), ante, susse);
  if (trace_on && !found)
    printf("-> Reply: not found\r\n");
  Substitute(risp, model[FoundKey - 1], "$", ante);
  strcpy(risp, Substitute(STR2, risp, "&", susse));

  Print(risp);

}


/* Load file .db e .key */

Static Void Load()
{
  Char buffer[256];
  FILE *KeyFile, *DBfile;
  boolean exist;
  Char *TEMP;
  char *r;
  printf("Leggo il file delle chiavi: %s\n",fabula_key);

  KeyFile=fopen(fabula_key,"r");

if ( KeyFile == NULL)
	{printf("fabula_key not existent!\r\n"); exit(1);}	

  /* rewind(KeyFile); */
  exist=true;

  nkey = 0;

  if (exist) {
    while ( 1 ) {
      r=fgets(buffer, 256, KeyFile);
      if( (int)r == 0 ) break ;
	fgets(key[nkey],256,KeyFile);
	op[nkey]=fgetc(KeyFile); fgetc(KeyFile);
	fgets(model[nkey],256,KeyFile);
	chop(key[nkey]);  chop(model[nkey]);
    /*
    printf("key %d,[%s],[%c],[%s]\n\r",nkey,key[nkey],op[nkey],model[nkey]);
    */
      nkey++;
    }
  }

      fclose(KeyFile);

  /* Carica db */

	DBfile=fopen(fabula_db,"r");
	if (DBfile == NULL)
		{printf("fabula_db non esistente!\r\n"); exit(1); }

  printf("Leggo il file del DB: %s\n",fabula_db);

   exist=true;
  ndb = 0;

  if (exist) {
    while (  1 ) {
    r=fgets(db[ndb], 256, DBfile);
    if ( ((int)r==0) || (ndb > MaxDB ) ) break;
	chop(db[ndb]);
	 /*
	 printf("db %d [%s]",ndb,db[ndb]); 
	*/
      ndb++;
    }
  }

    fclose(DBfile);
printf("Conosco %d chiavi e %d nozioni apprese dagli umani.\n",nkey,ndb);
printf("\n");
}


Static Void Status()
{
  Char skey[256], sdb[256];
  Char STR2[256];

  sprintf(skey, "%12ld", nkey);
  sprintf(sdb, "%12ld", ndb);

  putchar('\r');
  putchar('\n');
  sprintf(STR2, "Totale chiavi = %s", skey);
  Print(STR2);
  sprintf(STR2, "Dimensione DB = %s", sdb);
  Print(STR2);
  putchar('\r');
  putchar('\n');


}


/* Salva tutta la conoscenza di Fabula */
Static Void Save()
{
  int i;
  FILE *KeyFile, *DBfile;
  int FORLIM;


	KeyFile=fopen(fabula_key,"w");
	DBfile=fopen(fabula_db,"w");

	if ( (KeyFile == NULL) || (DBfile ==NULL) )
		{printf("Il DB di Fabula e' in sola lettura!.\r\n"); 
		sleep(3);
		exit(1);}

  if (KeyFile == NULL)
	{fprintf(stderr,"Keyfile not found!\n"); exit(1);}

  if (DBfile == NULL)
	{fprintf(stderr,"DBfile not found!\n"); exit(1);}

  FORLIM = nkey;

  for (i = 1; i <= FORLIM; i++) {
    fprintf(KeyFile, "------------------- key %12d\n", i);
    fprintf(KeyFile, "%s\n", key[i - 1]);
    fprintf(KeyFile, "%c\n", op[i - 1]);
    fprintf(KeyFile, "%s\n", model[i - 1]);
  }

    fclose(KeyFile);

  FORLIM = ndb;
  for (i = 0; i < FORLIM; i++)
    fprintf(DBfile, "%s\n", db[i]);

    fclose(DBfile);
}


Static Void Dimentica(frase)
Char *frase;
{
  int i;
  Char STR2[108];


  if (*frase == '\0') {
    Print("Dimenticare cosa?");
    return;
  }

  i = 1;
  do {
    if (strpos2(db[i - 1], frase, 1) != 0 || !strcmp(frase, "*")) {
      sprintf(STR2, "Dimentico che \"%s\"", db[i - 1]);
      Print(STR2);
      strcpy(db[i - 1], db[ndb - 1]);
      ndb--;
    }
    i++;
  } while (i <= ndb);


}


/* Fabula impara nuovi modelli di risposta */

Static Void Impara()
{
  StringType risp, buffer;
  boolean printer_old;
  Char STR2[256];

  printer_old = printer_on;
  printer_on = false;

  nkey++;
  printf("--------------------------\r\n");
  Print("Inserisci la Chiave di ricerca");
  printf("[ aggiungi ? se e' per frasi interrogative ]\r\n");
  ReadInput("Chiave? ", key[nkey - 1]);

  Print("Inserisci il Modello di risposta");
  printf("[ Usare i caratteri speciali $ (antecedente a Chiave)\r\n");
  printf(" & (susseguente a Chiave) per utilizzare parti\r\n");
  printf(" della frase in input ]\r\n");

  ReadInput("Modello? ", model[nkey - 1]);

  Print("Operazioni particolari, oltre che rispondere?");
  printf("[ > memorizza ; = cerca ; RETURN nessuna ]\r\n");
  ReadInput("Op? ", buffer);

  if (*buffer == '\0')
    op[nkey - 1] = ':';
  else
    op[nkey - 1] = buffer[0];


  putchar('\r');
  putchar('\n');

  ReadInput("Va bene cosi'? (y/n) ", risp);
  if (!strcmp(Upper(STR2, risp), "N")) {
    nkey--;
    Print("Ok, come non detto!");
  } else {
    NuoveChiavi++;
    Print("Imparato, grazie.");
  }

  printer_on = printer_old;

}


/* MAIN di fabula */
int main(argc, argv)
int argc;
Char *argv[];
{
  Char STR1[256];
  int i,n;
  char * letto;
/*
  PASCAL_MAIN(argc, argv);
*/
  srand(1);
interactive=1;

/* I/O senza buffer */

setvbuf(stdout,NULL,_IONBF,0);
setvbuf(stdin,NULL,_IONBF,0);


Init();

  do {
    putchar(':');
    UserInput[0]='\0';
    fgets(UserInput,256,stdin);
    chop(UserInput);
    CheckForEscape(UserInput);
    NumBattute++;

    if ( !strcmp(UserInput,"r") || !strcmp(UserInput,"ripeti")  )
		Interpret(LastInput);
    else
	{
    	Interpret(UserInput);
   	strcpy(LastInput,UserInput);
	}
  } while (strcmp(Upper(STR1, UserInput), "CIAO") );

  exit(EXIT_SUCCESS);
}



/* End. */
