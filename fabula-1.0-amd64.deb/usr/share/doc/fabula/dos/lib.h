/*
 Funzioni necessarie per eliminare la libreria Pascal
------------------------------------------------------
  */

 /*
 estrare una sottostring
 */

char* strsub(char *d, char *s, int start, int count )
{
int i=0;
start--;
for (i=0; i<count; i++ ) d[i]=s[start+i];
return d;
}

/*
posizione numerica di una sottostringa
*/

int strpos2(char *dove, char *cosa, int from )
{
int i=0;
char *p=0;
from--;
p=(char*) strstr( (const char*) (dove+from), (const char*) cosa);

/*
 scanning dei puntatori (portabile?)
*/

for (i=0; i<strlen(dove); i++ ) {
	if ( p == (char*)(dove+i) ) return i+1;
}

return 0;
}

 /*
 rimozione di sottoscringa
 */

void strdelete(char *s, int from, int count)
{
int i=0,j=0;
char *p;
char buffer[256];
strcpy(buffer,s);
buffer[strlen(s)]='\0';

from--;
/* bzero(s,strlen(s)); */

memset(s,0,strlen(s));

for (i=0; buffer[i]!='\0'; i++ )
{
	if (  (i>=from) && ( i< (from+count)) ) continue;
	s[j]=buffer[i]; j++;
}

}

 /*
 inserzione sottostringa
 */

void strinsert(char* obj, char* dove, int pos)
{
int i=0,j=0,k=0;
char buffer[256];
strcpy(buffer,dove);

pos--;
/* parte che precede */
for(; k<pos; i++ ) {dove[i]=buffer[k]; dove[i+1]='\0'; k++;}
/* inserzione */
for(; j<strlen(obj); i++) {dove[i]=obj[j]; dove[i+1]='\0';j++;}
/* parte rimanente */
for(; k<strlen(buffer); i++) {dove[i]=buffer[k]; k++;}

dove[i]='\0';

}

