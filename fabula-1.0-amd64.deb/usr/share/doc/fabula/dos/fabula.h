

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define Char char
#define Void void
#define Static static
typedef unsigned char boolean;
typedef char *Anyptr;

#define true    1
#define false   0

#ifndef TRUE
# define TRUE    1
# define FALSE   0
#endif
#ifndef EXIT_SUCCESS
# define EXIT_SUCCESS  1
# define EXIT_FAILURE  (02000000000L)
#endif

#define PP(x) ()
#define PV

